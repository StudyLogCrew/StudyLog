import java.awt.Color;
import javax.swing.JFrame;
public class Main {

	public static void main(String[] args) {
		Boolean leitourgia=true;
		while(leitourgia){
			leitourgia=PreLoginMenu.functionable();
		}
	}
}